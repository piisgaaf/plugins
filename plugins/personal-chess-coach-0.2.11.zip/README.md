# Personal Chess Coach Plugin

A Cowork plugin that brings a Stockfish-powered personal chess coach into Claude.

## What it does

The coach answers *"Why?"* rather than *"What?"*. Instead of just finding the best move, it explains plans, motifs, and mistakes — and builds a Player Profile over time so it gets to know you as a player.

**Current capabilities (F01–F10):**
- Analyze positions and explain the best move
- Compare candidate moves
- Identify openings and typical plans
- Analyze full games (PGN)
- Show critical moments and coach-style annotations
- Classify mistakes and explain their root causes
- Learn how you think and play

## Components

| Component | Description |
|-----------|-------------|
| Skill: `personal-chess-coach` | The coaching skill — routes all chess requests |
| MCP: `chess-engine-mcp` | Connects to the local Stockfish-backed analysis server over HTTPS |

## Architecture

```
Claude (Cowork)          MCP Inspector / local dev
      │                          │
      │  HTTPS (localhost:4443)  │  HTTP (localhost:4100)
      └──────────────┬───────────┘
                     ▼
        chess-engine MCP server  (Podman container)
                     │
                     ├── Stockfish          (position analysis, best move, evaluation)
                     └── Lichess Explorer   (opening continuations, requires API token)
```

The server exposes two listeners on the same router and engine pool:

- **HTTPS on 4443** — required by Cowork plugin connectors, which only accept secure connections even for localhost. The TLS certificate is managed by **mkcert**, a tool that creates a local Certificate Authority (CA) trusted by your machine, so connections are accepted silently without warnings.
- **HTTP on 4100** — for the MCP Inspector and other local development tools that do not use the macOS keychain and would reject a TLS certificate.

The Lichess API token is injected into the container as a Podman secret — it is never passed as a plaintext environment variable or baked into the image.

## Setup

### 1. Install mkcert and generate the certificate

mkcert creates a locally-trusted TLS certificate for `localhost`. You only need to run the install step once per machine.

```sh
brew install mkcert
mkcert -install           # installs the local CA into your keychain (once ever)
cd chess_engine/priv/cert
mkcert localhost          # generates localhost.pem and localhost-key.pem
```

Then rename the generated files to match the names the server expects:

```sh
mv localhost.pem selfsigned.pem
mv localhost-key.pem selfsigned_key.pem
```

> **Why mkcert?** The alternative — a self-signed certificate — is rejected by Cowork and most HTTP clients unless you manually add a per-client exception. mkcert avoids this by making your machine trust the certificate at the OS level. The `mcp-remote` bridge connects over plain HTTP (port 4100), so it is unaffected by TLS.

### 2. Set the Lichess API token

The chess engine uses the Lichess Opening Explorer for opening continuations. This requires a personal access token (no special scopes needed — read-only access).

1. Create a token at [lichess.org/account/oauth/token](https://lichess.org/account/oauth/token)
2. Store it in `~/.secrets/chess.env`:

```sh
export LICHESS_API_TOKEN=lip_xxxxxxxxxxxxxxxxxxxx
```

3. Run `direnv allow` once in the `chess_engine` project root (uses `.envrc` to load the file automatically).

### 3. Start the chess engine server

```sh
cd chess_engine
mix podman.build   # build the container image (once, or after code changes)
mix podman.run     # inject the Lichess token and start the container
```

The server listens on:
- `https://localhost:4443/mcp` — Cowork plugin connector
- `http://localhost:4100/mcp` — MCP Inspector and local dev

### 4. Configure a Player Profile

The coach maintains a YAML player profile in your Cowork project folder. On first use, it will ask which profile to load or offer to create one.

## Usage

Just talk to Claude naturally:

- "Analyze this position: `r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 4 4`"
- "Why is Ng5 the best move here?"
- "Compare Nf3 and d4 in this position"
- "Analyze my game" (then paste a PGN)
- "What kind of mistakes do I keep making?"

## Roadmap

Future versions will add:
- Lichess connector — query your games and tournaments directly
- Chess.com connector — same for Chess.com
- Club magazine skill — write human-sounding game annotations for your local chess magazine

## How this was built

This project was developed by Pieter Rijken with the help of Claude Code
(Anthropic). The design, the chess-coaching approach and every change were
directed and reviewed by the author.

## License

[PolyForm Noncommercial License 1.0.0](LICENSE): free to use, change and share
for any noncommercial purpose. Commercial use is not allowed without the
author's permission.
